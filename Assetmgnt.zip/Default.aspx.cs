﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
    DataTable dt = new DataTable();
    protected void Page_Load(object sender, EventArgs e)
    { 
        
        string connStr = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
        using (SqlConnection con = new SqlConnection(connStr))
        {
            
            dt.Columns.Add("asset ID", typeof(string));
            dt.Columns.Add("Asset Name", typeof(string));
            dt.Columns.Add("DOP", typeof(string));
            dt.Columns.Add("Invoice ID", typeof(int));
            dt.Columns.Add("Status", typeof(string));



            con.Open();
            SqlCommand cmd = new SqlCommand("spSelect", con);
            cmd.CommandType = CommandType.StoredProcedure;


            using (SqlDataReader rdr = cmd.ExecuteReader(CommandBehavior.CloseConnection))
            {
                while (rdr.Read())
                {

                    string assetId = rdr.GetString(rdr.GetOrdinal("asset_id"));
                    string type = rdr.GetString(rdr.GetOrdinal("type"));
                    string DOP = rdr.IsDBNull(rdr.GetOrdinal("DOP")) ? "" : rdr.GetDateTime(rdr.GetOrdinal("DOP")).ToString();
                    string Invoice_ID = rdr.IsDBNull(rdr.GetOrdinal("Invoice_ID")) ? "" : rdr.GetInt32(rdr.GetOrdinal("Invoice_ID")).ToString();
                    string status = rdr.IsDBNull(rdr.GetOrdinal("status")) ? "" : rdr.GetString(rdr.GetOrdinal("status"));


                    dt.Rows.Add(assetId, type, DOP, Invoice_ID, status);


                }
                rdr.Close();

                gridView2.DataSource = dt;
                gridView2.DataBind();
                con.Close();
                foreach (GridViewRow row in gridView2.Rows)
                {
                    if (row.Cells[5].Text.Trim() == "A")
                    {
                        row.Cells[1].FindControl("btnDeallocate").Visible = true;
                        row.Cells[1].FindControl("btnAllocate").Visible = false;

                    }
                    else
                    {
                        row.Cells[1].FindControl("btnDeallocate").Visible = false;
                        row.Cells[1].FindControl("btnAllocate").Visible = true;
                    }
                }
            }

        }
    }
    protected void Tab1_Click(object sender, EventArgs e)
    {
        gridView1.Visible = true;
        btnAssetDstbd.CssClass = "Clicked";
        btnAssetIntry.CssClass = "Intial";
        multiView1.ActiveViewIndex = 0;
    }
    protected void Tab2_Click(object sender, EventArgs e)
    {
        gridView2.Visible = true;
        btnAssetIntry.CssClass = "Clicked";
        btnAssetDstbd.CssClass = "Intial";
        multiView1.ActiveViewIndex = 1;
    }
    ////protected void TxtDstn_Click(object sender, EventArgs e)
    ////{
    ////    string connStr = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
    ////    using (SqlConnection con = new SqlConnection(connStr))
    ////    {
    ////        con.Open();
    ////        string query = "select *  from employee where emp_id  like'" + txtDist.Text + "%'";
    ////        SqlCommand com = new SqlCommand(query, con);

    ////        SqlDataReader dr;
    ////        dr = com.ExecuteReader();

    ////        if (txtDist.Text.Trim() == string.Empty)
    ////        {
    ////            gridView1.Visible = false;
    ////            LbDstn.Visible = true;
    ////            LbDstn.Text = "enter a value!!!";


    ////        }
    ////        else if (dr.HasRows)
    ////        {
    ////            dr.Read();

    ////            emp_search();
    ////            gridView1.Visible = true;

    ////            Txtinven.Text = "";
    ////            LbDstn.Visible = false;


    ////        }
    ////            else
    ////        {
    ////            gridView1.Visible = false;
    ////            LbDstn.Text = "no results found!!!!";
    ////            LbDstn.Visible = true;
    ////        }


           

    ////    }
    ////}
    ////private void emp_search()
    ////{
    ////    string connStr = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
    ////    using (SqlConnection con = new SqlConnection(connStr))
    ////    {

    ////        con.Open();
    ////        string query = "select * from employee where emp_id like'" + txtDist.Text + "%'";

    ////        SqlDataAdapter da = new SqlDataAdapter(query, con);
    ////        DataSet ds = new DataSet();
    ////        da.Fill(ds);
    ////        gridView2.DataSource = ds;
    ////        gridView2.DataBind();
    ////        con.Close();
    ////    }
    ////}

    private void inven_search()
    {
        string connStr = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
        using (SqlConnection con = new SqlConnection(connStr))
        {

            con.Open();
            string query = "select * from inventory where type like'" + Txtinven.Text + "%'";

            SqlDataAdapter da = new SqlDataAdapter(query, con);
            DataSet ds = new DataSet();
            da.Fill(ds);
            gridView2.DataSource = ds;
            gridView2.DataBind();
            con.Close();
        }
    }
    protected void btnInven_Click(object sender, EventArgs e)
    {
        string connStr = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
        using (SqlConnection con = new SqlConnection(connStr))
        {
            con.Open();
            string query = "select *  from inventory where type like'" + Txtinven.Text + "%'";
            SqlCommand com = new SqlCommand(query, con);

            SqlDataReader dr;
            dr = com.ExecuteReader();

            if (Txtinven.Text.Trim() == string.Empty)
            {
                gridView2.Visible = false;
                Lbinven1.Visible = true;
                Lbinven1.Text = "enter a value!!!";

            }
            else if (dr.HasRows)
            {
                dr.Read();

                inven_search();
                gridView2.Visible = true;

                Txtinven.Text = "";
                Lbinven1.Visible = false;


            }
            else
            {
                gridView2.Visible = false;
                Lbinven1.Text = "no results found!!!!";

            }
        }
    }
    protected void LinkButton2_Click(object sender, EventArgs e)
    {
        Lbinven1.Visible = false;
        gridView2.Visible = true;
    }

    
   
    protected void btnInsert_Click1(object sender, EventArgs e)
    {
        string connStr = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
        using (SqlConnection con = new SqlConnection(connStr))
        {

            con.Open();
            string query = "INSERT INTO employee(emp_id, emp_name, asset_id,asset_name,dop,status) VALUES(@emp_id, @emp_name, @asset_id,@asset_name,@dop,@status)";
            SqlCommand com = new SqlCommand(query, con);



            com.Parameters.AddWithValue("@emp_id", Convert.ToInt32(txtInsert.Text));
            com.Parameters.AddWithValue("@emp_name", Convert.ToString(TxtInsertName.Text));
            com.Parameters.AddWithValue("@asset_id", hdassetid.Value);
            com.Parameters.AddWithValue("@asset_name", hdassetname.Value);
            com.Parameters.AddWithValue("@dop", Convert.ToString(DateTime.Now));
            com.Parameters.AddWithValue("@status", "A");
            com.ExecuteNonQuery();
            gridView2.DataBind();
            con.Close();
            LbSucess.Visible = true;
            gridView2.Visible = false;
        }

    }
   
    protected void gridView2_PageIndexChanged(object sender, GridViewPageEventArgs e)
    {
        gridView2.PageIndex = e.NewPageIndex;
         gridView2.DataBind();

    }
    
protected void txtDist_TextChanged(object sender, EventArgs e)
{

}
protected void TxtInsertDate_TextChanged(object sender, EventArgs e)
{
    //TxtInsertDate.Text = DateTime.Now.ToShortDateString();
}
}