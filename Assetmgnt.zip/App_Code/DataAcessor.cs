﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for DataAcessor
/// </summary>
public class DataAcessor
{
    protected bool GetStatus()
    {
        string connStr = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;

    }
}