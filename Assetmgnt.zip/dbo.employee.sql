﻿CREATE TABLE [dbo].[employee] (
    [emp_id]        INT           NOT NULL,
    [emp_name]      NCHAR (10)    NOT NULL,
    [asset_id]         NVARCHAR (50) NOT NULL,
    [asset_name]    CHAR (20)     NULL,
    [dop]           DATE          NULL,
    [status]        CHAR (10)     NULL,
    [emp_user_name] AS            ('EMP' + RIGHT('0000' + CONVERT (VARCHAR (5), [emp_id]), (5))) PERSISTED,
    PRIMARY KEY CLUSTERED ([emp_id] ASC, [asset_id] ASC), 
   -- CONSTRAINT [FK_employee_inventory] FOREIGN KEY ([asset_id]) REFERENCES [dbo].[inventory]([asset_id])
);

